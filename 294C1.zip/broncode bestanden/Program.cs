﻿using System;
using System.Collections.Generic;

namespace Opgave294C1
{
    class Program
    {
        static void Main(string[] args)
        {
            //aanmaken verschillende speler objecten en de gegevens naar de console schrijven
            var speler1 = new Speler("tralalala");
            var speler2 = new Speler("blablabla", 32);
            var speler3 = new Speler("yooo", 27, "spits");
            Console.WriteLine("Speler1: {0}", speler1.Naam);
            Console.WriteLine("Speler2: {0} {1}", speler2.Naam, speler2.Leeftijd);
            Console.WriteLine("Speler3: {0} {1} {2}", speler3.Naam, speler3.Leeftijd, speler3.Rol);

            Console.WriteLine();
            //test voor het berekenen van het gemiddelde cijfer. voeg eerst cijfers toe, vervolgens gemiddelde naar de console schrijven
            speler1.SetCijferLaatsteWedstrijd(5.0);
            speler1.SetCijferLaatsteWedstrijd(7.5);
            speler1.SetCijferLaatsteWedstrijd(6.5);
            speler1.SetCijferLaatsteWedstrijd(5.7);
            Console.WriteLine("gemiddeld cijfer: " +  Math.Round(speler1.GetGemiddeldCijfer(), 1));

            Console.WriteLine();
            //aanmaken coach objecten en de gegevens naar de console schrijven
            var coach1 = new Coach() { Naam = "Hohohoh", Leeftijd = 47 };
            var coach2 = new Coach("Lalala");
            var coach3 = new Coach("tsatsatsa", 63);
            Console.WriteLine("Coach1: {0} {1}", coach1.Naam, coach1.Leeftijd);
            Console.WriteLine("Coach2: {0} {1}", coach2.Naam, coach2.Leeftijd);
            Console.WriteLine("Coach3: {0} {1}", coach3.Naam, coach3.Leeftijd);

            Console.WriteLine();
            //aanmaken team, toevoegen van een coach en een aantal leden. Vervolgens de teamgegevens, -coach en -leden naar de console schrijven.
            //gegevens van de spelers zullen default values bevatten omdat voor speler1 en speler2 niet alle data is aangeleverd.
            var team = new Team() { Naam = "voetbalclub" };
            team.Coach = coach1;
            var spelers = new List<Speler>();
            spelers.Add(speler1);
            spelers.Add(speler2);
            spelers.Add(speler3);

            Console.WriteLine("Teamnaam: {0}", team.Naam);
            Console.WriteLine("Coach van het team: {0}", team.Coach.Naam);
            Console.WriteLine("Spelers van het team:");
            foreach(var speler in spelers)
            {
                Console.WriteLine("Naam speler: {0}, leeftijd: {1}, rol: {2}", speler.Naam, speler.Leeftijd, speler.Rol);
            }

            //Console.ReadLine() om te voorkomen dat de console window meteen sluit bij het runnen van de .exe van deze app.
            Console.ReadLine();
        }
    }
}
