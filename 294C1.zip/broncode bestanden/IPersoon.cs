﻿namespace Opgave294C1
{
    public interface IPersoon
    {
        string Naam { get; set; }
        int Leeftijd { get; set; }
    }
}
