﻿namespace Opgave294C1
{
    public class Coach : IPersoon
    {
        public string Naam { get; set; }
        public int Leeftijd { get; set; }

        //Meerdere constructors om de mogelijkheid te geven op meerdere manieren een instantie van Coach aan te maken
        public Coach() { }

        public Coach(string naam)
        {
            this.Naam = naam;
        }

        public Coach(string naam, int leeftijd) : this(naam)
        {
            this.Leeftijd = leeftijd;
        }
    }
}
