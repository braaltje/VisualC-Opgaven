﻿using System.Collections.Generic;

namespace Opgave294C1
{
    public class Speler : IPersoon
    {
        public string Naam { get; set; }
        public int Leeftijd { get; set; }
        public string Rol { get; set; }
        public readonly List<double> behaaldeCijfers = new List<double>();

        //Meerdere constructors om de mogelijkheid te geven op meerdere manieren een instantie van Speler aan te maken
        public Speler() { }

        public Speler(string naam)
        {
            this.Naam = naam;
        }

        public Speler(string naam, int leeftijd) : this(naam)
        {
            this.Leeftijd = leeftijd;
        }

        public Speler (string naam, int leeftijd, string rol) : this(naam, leeftijd)
        {
            this.Rol = rol;
        }
        
        //Method om het gemiddelde cijfer te berekenen. Totaal van het cijfers gedeeld door het aantal.
        private double BerekenGemiddeldCijfer()
        {
            var behaaldeCijfers = GetBehaaldeCijfers();
            var totaalCijfers =  0.0;

            foreach(double cijfer in behaaldeCijfers)
            {
                totaalCijfers += cijfer;
            }

            return totaalCijfers / behaaldeCijfers.Count;
        }

        //Public method om het gemiddelde cijfer op te vragen. Classes buiten Speler hebben geen weet van de berekening
        //van het gemiddelde cijfer.
        public double GetGemiddeldCijfer()
        {
            return BerekenGemiddeldCijfer();
        }

        public List<double> GetBehaaldeCijfers()
        {
            return behaaldeCijfers;
        }

        public void SetCijferLaatsteWedstrijd(double cijfer)
        {
            behaaldeCijfers.Add(cijfer);
        }
    }
}
