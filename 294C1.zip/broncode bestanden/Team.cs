﻿using System.Collections.Generic;

namespace Opgave294C1
{
    public class Team
    {
        public string Naam { get; set; }
        public Coach Coach { get; set; }
        private readonly List<IPersoon> _TeamLeden = new List<IPersoon>();


        ////Meerdere constructors om de mogelijkheid te geven op meerdere manieren een instantie van Team aan te maken
        public Team() { }

        public Team(Coach coach)
        {
            this.Coach = coach;
        }

        public Team(Coach coach, List<IPersoon> teamLeden) : this(coach)
        {
            this._TeamLeden = teamLeden;
        }

        //method om een nieuw lid toe te voegen
        public void SetLid(IPersoon lid)
        {
            _TeamLeden.Add(lid);
        }

        public List<IPersoon> GetLeden()
        {
            return _TeamLeden;
        }


    }
}
