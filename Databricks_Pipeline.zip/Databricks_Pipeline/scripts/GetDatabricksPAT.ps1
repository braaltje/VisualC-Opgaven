#######################################################
# PowerShell script to obtain PAT from Databricks workspace
# Requirements:
# Parameters:
#   - Databricks Workspace URL e.g.: "https://adb-xxxx.xx.azuredatabricks.net"
# Author:
#   Angelica Garrido
#   Created on: January 9th, 2023
#   Last Revision: January 9th, 2023
# Example call function: .\PATDatabricks.ps1 $DatabricksWorkspaceURL -Verbose
####################################################
[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [String]
    $DatabricksWorkspaceURL
)

$Global:authHeader = $null

function Connect-GraphAPI {
    $token = & az account get-access-token --resource=2ff814a6-3304-4ab8-85cb-cd0e6f879c1d --query accessToken
    $token = $token -replace '"',''
    $Header = @{
        'Authorization' = 'Bearer ' + $token
    }
    Write-Host("##vso[task.setvariable variable=dataBricksToken]$token")
    Set-Variable -Name "authHeader" -Value $Header -Scope global
}

function deletePATS {
    param (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]
        $DatabricksWorkspaceURL,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]
        $token_id
    )

    $databricksListTokenURL = "$DatabricksWorkspaceURL/api/2.0/token/delete"
    $body = @{
        'token_id'         = $token_id
    } | ConvertTo-Json

    $parameters = @{
        'Uri'         = $databricksListTokenURL
        'Method'      = 'Post'
        'Headers'     = ${Global:authHeader}
        'Body'        = $body
        'ContentType' = 'application/json'
    }
    try {
        $response = Invoke-RestMethod @parameters
        # Write-Output "Response: ${response}"
    }
    catch {
        Write-Error "REST API to delete Databricks PAT failed $($_.Exception.Message)"
        throw "REST API call failed"
    }
}
 
function listAndDeletePATS {
    param (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]
        $DatabricksWorkspaceURL
    )
    $databricksListTokenURL = "$DatabricksWorkspaceURL/api/2.0/token/list"
    $parameters = @{
        'Uri'         = $databricksListTokenURL
        'Method'      = 'Get'
        'Headers'     = ${Global:authHeader}
    }
    Write-Verbose "Invoking REST API to list Databricks PATs"
    try {
        $response = Invoke-RestMethod @parameters
        # Write-Verbose "Response: ${response}"
    }
    catch {
        Write-Error "REST API to get Databricks PAT failed $($_.Exception.Message)"
        throw "REST API call failed"
    }
    if ($null -ne $response."token_infos") {
        For ($i = 0; $i -le  $response."token_infos".length; $i++) {
            if ($response."token_infos"[$i].comment -eq "$DatabricksWorkspaceURL-PAT created for SCIM application") {
                ## Delete Token
                $token_id = $response."token_infos"[$i].token_id
                Write-Verbose "Deleting Token ${token_id}"
                deletePATS -DatabricksWorkspaceURL $DatabricksWorkspaceURL -token_id $token_id
            }
        }
    }
}
 
function createPATS {
    param (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]
        $DatabricksWorkspaceURL
    )
 
    # Set Databricks API Create Token URL
    $databricksCreateTokenURL = "$DatabricksWorkspaceURL/api/2.0/token/create"
    # Set body for REST call, Lifetime is 90 days
    $body = @{
        'comment'          = "$DatabricksWorkspaceURL-PAT created for SCIM application"
        'lifetime_seconds' = '7776000'
    } | ConvertTo-Json
 
    # Define parameters for REST method
    $parameters = @{
        'Uri'         = $databricksCreateTokenURL
        'Method'      = 'Post'
        'Headers'     = ${Global:authHeader}
        'Body'        = $body
        'ContentType' = 'application/json'
    }
 
    # Invoke REST API
    Write-Verbose "Invoking REST API to create Databricks PAT"
    try {
        $response = Invoke-RestMethod @parameters
        Write-Verbose "Response: ${response}"
    }
    catch {
        Write-Error "REST API to get Databricks PAT failed $($_.Exception.Message)"
        throw "REST API call failed"
    }
    return $response.token_value                
}
 
Write-Verbose "Get ADD Token"
Connect-GraphAPI
 
Write-Verbose "Attempting Delete Existing PATs with Same Comments to $DatabricksWorkspaceURL"
listAndDeletePATS -DatabricksWorkspaceURL $DatabricksWorkspaceURL
 
Write-Verbose "Create New Databricks PAT"
$DatabricksPAT = createPATS -DatabricksWorkspaceURL $DatabricksWorkspaceURL
 
Write-Host "##vso[task.setvariable variable=DATABRICKS_PAT]$DatabricksPAT"